# Projeto do Curso de Otimização de Performance Web II do Alura

Clone o projeto e faça `npm install` para instalar as dependências do gulp.
